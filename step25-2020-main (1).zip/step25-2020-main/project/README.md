To run a local server, execute this command:

```bash
mvn package appengine:run
```