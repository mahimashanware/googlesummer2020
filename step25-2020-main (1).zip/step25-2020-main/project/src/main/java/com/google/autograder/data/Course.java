public final class Course {
    private String name;
    private String id;
}